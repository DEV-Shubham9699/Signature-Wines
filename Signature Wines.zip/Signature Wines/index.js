 // Mobile Menu Toggle
        const mobileMenu = document.getElementById('mobile-menu');
        const navLinks = document.getElementById('nav-links');
        
        mobileMenu.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenu.querySelector('i').classList.toggle('fa-bars');
            mobileMenu.querySelector('i').classList.toggle('fa-times');
        });

        // Close mobile menu when clicking a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                mobileMenu.querySelector('i').classList.add('fa-bars');
                mobileMenu.querySelector('i').classList.remove('fa-times');
            });
        });

        // Header scroll effect
        const header = document.getElementById('header');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        });

        // Image Slider
        const slider = document.getElementById('slider');
        const prevBtn = document.getElementById('prev');
        const nextBtn = document.getElementById('next');
        let slideIndex = 0;

        function showSlide(index) {
            if (index < 0) {
                slideIndex = slider.children.length - 1;
            } else if (index >= slider.children.length) {
                slideIndex = 0;
            }
            slider.style.transform = `translateX(-${slideIndex * 100}%)`;
        }

        prevBtn.addEventListener('click', () => {
            slideIndex--;
            showSlide(slideIndex);
        });

        nextBtn.addEventListener('click', () => {
            slideIndex++;
            showSlide(slideIndex);
        });

        // Auto slide
        setInterval(() => {
            slideIndex++;
            showSlide(slideIndex);
        }, 5000);

        // Scroll animations
        function animateOnScroll() {
            const productCards = document.querySelectorAll('.product-card');
            const premiumItems = document.querySelectorAll('.premium-item');
            
            productCards.forEach(card => {
                const cardPosition = card.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (cardPosition < screenPosition) {
                    card.classList.add('visible');
                }
            });
            
            premiumItems.forEach(item => {
                const itemPosition = item.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (itemPosition < screenPosition) {
                    item.classList.add('visible');
                }
            });
        }

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);

        // Form submission
        const contactForm = document.getElementById('contactForm');
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('Thank you for your message! We will contact you soon.');
            contactForm.reset();
        });